# itu-proj
ITU project 2024/2025

## Types of the gems:

0 - red
1 - yellow
2 - green
3 - blue
4 - bomb
5 - heart

## Map size

6x6